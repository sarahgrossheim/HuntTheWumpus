// ---------------------------------------------------------------------------
// Name: Sarah Grossheim
// Course-Section: CS255-01
// Assignment: Project 5 - Hunt the Wumpus
// Date due: 03/12/2023
// Description: Write the play(), reportPosition(), and movePlayer() functions
//				for the Hunt the Wumpus project. 
// ---------------------------------------------------------------------------
#include <iostream>
using namespace std;

#include "Chamber.h"

Chamber::Chamber(int id, Chamber* d1, Chamber* d2, Chamber* d3)
{
    chamberID = id;
    door1 = d1;
    door2 = d2;
    door3 = d3;
}

void Chamber::setPtrs(Chamber* d1, Chamber* d2, Chamber* d3)
{
    door1 = d1;
    door2 = d2;
    door3 = d3;
}

int Chamber::getID()
{
    return chamberID;
}

int Chamber::getDoor1ID()
{
    return door1->getID();
}

int Chamber::getDoor2ID()
{
    return door2->getID();
}

int Chamber::getDoor3ID()
{
    return door3->getID();
}

Chamber* Chamber::getDoor1Ptr()
{
    return door1;
}

Chamber* Chamber::getDoor2Ptr()
{
    return door2;
}

Chamber* Chamber::getDoor3Ptr()
{
    return door3;
}

