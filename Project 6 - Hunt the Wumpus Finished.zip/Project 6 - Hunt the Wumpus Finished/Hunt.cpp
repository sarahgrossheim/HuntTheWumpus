// ---------------------------------------------------------------------------
// Name: Sarah Grossheim
// Course-Section: CS255-01
// Assignment: Project 5 - Hunt the Wumpus
// Date due: 03/12/2023
// Description: Write the play(), reportPosition(), and movePlayer() functions
//				for the Hunt the Wumpus project. 
// ---------------------------------------------------------------------------
#ifndef Incl_Chamber
#define Incl_Chamber
#include "Chamber.h"
#endif // Include Chamber

#ifndef Incl_Hunt
#define Incl_Hunt
#include "Hunt.h"
#endif // Include Hunt

#include <iostream>
using namespace std;


Hunt::Hunt()
{
	//constructor
	int rtemp;
	
	//Create a temporary array of Chamber pointers 
	//(this array has a local scope and will be deleted)
	Chamber* ptrArray[20];
	
	//Dynamically allocate 20 Chamber objects, each pointed to by a pointer in the array
	for(int i=0; i<20; i++)
	{
    		ptrArray[i] = new Chamber(i+1, nullptr, nullptr, nullptr);
	}
	//Set the Chambers to point to one another to build your game map
	//The map is based on an icosahedron (d-20), see class discussion
	ptrArray[0]->setPtrs(ptrArray[6], ptrArray[18], ptrArray[12]);
	ptrArray[1]->setPtrs(ptrArray[11], ptrArray[17], ptrArray[19]);
	ptrArray[2]->setPtrs(ptrArray[16], ptrArray[15], ptrArray[18]);
	ptrArray[3]->setPtrs(ptrArray[17], ptrArray[10], ptrArray[13]);
	ptrArray[4]->setPtrs(ptrArray[17], ptrArray[14], ptrArray[13]);
	ptrArray[5]->setPtrs(ptrArray[8], ptrArray[15], ptrArray[13]);
	ptrArray[6]->setPtrs(ptrArray[16], ptrArray[0], ptrArray[14]);
	ptrArray[7]->setPtrs(ptrArray[9], ptrArray[19], ptrArray[15]);
	ptrArray[8]->setPtrs(ptrArray[5], ptrArray[10], ptrArray[18]);
	ptrArray[9]->setPtrs(ptrArray[16], ptrArray[11], ptrArray[7]);
	ptrArray[10]->setPtrs(ptrArray[8], ptrArray[3], ptrArray[12]);
	ptrArray[11]->setPtrs(ptrArray[9], ptrArray[14], ptrArray[1]);
	ptrArray[12]->setPtrs(ptrArray[10], ptrArray[4], ptrArray[0]);
	ptrArray[13]->setPtrs(ptrArray[3], ptrArray[5], ptrArray[19]);
	ptrArray[14]->setPtrs(ptrArray[4], ptrArray[11], ptrArray[6]);
	ptrArray[15]->setPtrs(ptrArray[5], ptrArray[2], ptrArray[7]);
	ptrArray[16]->setPtrs(ptrArray[9], ptrArray[2], ptrArray[6]);
	ptrArray[17]->setPtrs(ptrArray[4], ptrArray[3], ptrArray[1]);
	ptrArray[18]->setPtrs(ptrArray[2], ptrArray[8], ptrArray[0]);
	ptrArray[19]->setPtrs(ptrArray[1], ptrArray[13], ptrArray[7]);

	//set gameOver bool to false
	gameOver = false;

	//set the player to begin in the first chamber
	player = ptrArray[0];

	//give the bats, the pit, and the wumpus a random starting chamber (not chamber 1)
	rtemp = rand()%18+1; //random values between 1 and 19, exclude 0
	wumpus = ptrArray[rtemp];
	cout<<"CHEATING: Wumpus Location: "<<wumpus->getID()<<endl;
	rtemp = rand()%18+1; //random values between 1 and 19, exclude 0
	bats = ptrArray[rtemp];
	cout<<"CHEATING: Bats Location: "<<bats->getID()<<endl;
	rtemp = rand()%18+1; //random values between 1 and 19, exclude 0
	pit = ptrArray[rtemp];
	cout<<"CHEATING: Pit Location: "<<pit->getID()<<endl;

	//set the number of arrows
	numArrows=5;
}

void Hunt::play()
{
	while(gameOver!=true)
	{
		// Variable for door selection
		int move;
		// Variable for if the arrow hit or missed
		int arrow;
		
		// Tell user about their surroundings
		reportPosition();
		
		// Ask user to make their door selection
		cout << "Make a door selection: 1, 2, or 3, or press 4 to fire an arrow." << endl;
		cin >> move;
		
		// If user picks 1-3, move player based on user's selection
		if(move > 0 && move < 4)
		{
			movePlayer(move);
		}
		
		// If user picks 4, fire arrow
		else if(move == 4)
		{
			arrow = fire();
			
			// If arrow hits
			if(arrow == 1)
			{
				// Wumpus is killed, Game over
				cout << "Congratulations! You killed the Wumpus! Game Over." << endl;
				gameOver = true; 
			}
			// If arrow misses
			else if(arrow == 0)
			{
				// Tell user that they missed
				cout << "Your shot flew harmlessly into the darkness. ";
				cout << "The sound spooked the Wumpus." << endl;
				
				// Take away an arrow
				--numArrows;
				
				// Display number of arrows remaining
				cout << "You have " << numArrows << " arrows remaining." << endl;
				
				// Move Wumpus to a different chamber
				moveWumpus();
			}
		}
		
		// Check 3 conditions: 
		// 1. Player in wumpus's chamber
		if(wumpus->getID() == player->getID())
		{
			killPlayer(1);
		}
		// 2. Player in pit chamber
		else if(pit->getID() == player->getID())
		{
			killPlayer(2);
		}
		// 3. Player in bats chamber
		else if(bats->getID() == player->getID())
		{
			randomFlight();
		}
	}
}

void Hunt::reportPosition()
{
	// Report which chamber you are currently in
	cout << "You are in Chamber " << player->getID() << ": " << endl;

	// Reports door 1 - 3 chambers and drops the clues
	for(int i = 0; i < 20; i++)
	{
		if(player -> getID() == i)
		{
			// When close to wumpus
			if((wumpus == player->getDoor1Ptr()) || (wumpus == player->getDoor2Ptr())
				|| (wumpus == player->getDoor3Ptr()))
			{                                                       
				cout << "You smell a terrible smell." << endl;
			}
	
			// When close to bats
			if((bats == player->getDoor1Ptr()) || (bats == player->getDoor2Ptr())
				|| (bats == player->getDoor3Ptr()))
			{
				cout << "You hear flapping wings and rushing wind." << endl;
			}
	
			// When 3 blocks close to the pit
			if((pit == player->getDoor1Ptr()) || (pit == player->getDoor2Ptr())
				|| (pit == player->getDoor3Ptr()))
			{
				cout << "You feel a breeze nearby." << endl;
			}
			
			// Report door 1 - 3
    		cout<<"\t Door 1 leads to Chamber "<<player->getDoor1ID()<<endl;
    		cout<<"\t Door 2 leads to Chamber "<<player->getDoor2ID()<<endl;
    		cout<<"\t Door 3 leads to Chamber "<<player->getDoor3ID()<<endl;
		}
	}
}

void Hunt::movePlayer(int move)
{
	// When user picks door1, change player to door1's ptr
	if(move == 1)
	{
		player = player->getDoor1Ptr();
	}
	// When user picks door2, change player to door2's ptr
	else if(move == 2)
	{
		player = player->getDoor2Ptr();
	}
	// When user picks door3, change player to door3's ptr
	else if(move == 3)
	{
		player = player->getDoor3Ptr();
	}
	// If user doesn't pick 1-3, print error message
	else
	{
		cout << "Invalid Selection!!" << endl;
	}
}

void Hunt::randomFlight()
{
	// Random number variables
	int numMoves;
	int move;

	// Create random number between 3 and 7, inclusive
	numMoves = rand()%5+3;

	// Keep moving to a different door until the numMoves is 0
	while(numMoves!=0)
	{
		// Create a random move between 1 and 3 to pick which door to go through
		move = rand()%3+1;
		// Move player with the random move between 1 and 3
		movePlayer(move);
		// Subtract the number of moves by 1
		numMoves--;
	}
	// Tell user that they have been moved by bats
	cout << "Bats! You've been lifted and dropped in a random place!" << endl;
	
	// If the bats drop the player in the pit or the wumpus chamber, kill them
	// 1. Player in wumpus's chamber
	if(wumpus->getID() == player->getID())
	{
		killPlayer(1);
	}
	// 2. Player in pit chamber
	else if(pit->getID() == player->getID())
	{
		killPlayer(2);
	}
}

void Hunt::killPlayer(int move)
{
	// If parameter passed in is 1, user dies from the Wumpus
	if(move == 1)
	{
		cout << "The Wumpus rends you limb from limb. You make a fantastic snack. Game over!" << endl;
	}
	// Else parameter passed in was 2, so user dies from the pit
	else
	{
		cout << "You've fallen to your death into a deep dark pit. Game over!" << endl;
	}
	gameOver = true;
}

int Hunt::fire()
{
	int door;
	int hit;
	
	// If you have arrows left
	if(numArrows > 0)
	{
		// Ask user for selection
		cout << "Choose a door to fire your arrow in to(1, 2, or 3:) ";
		cin >> door;
		
		if(door == 1)
		{
			// If wumpus is in door 1 that you fired into
			if(wumpus == player->getDoor1Ptr())
			{
				hit = 1;
			}
			// If shot missed
			else
			{
				hit = 0;
			}	
		}
		
		else if(door == 2)
		{
			// If wumpus is in door 2 that you fired into
			if(wumpus == player -> getDoor2Ptr())
			{
				hit = 1;
			}
			// If shot missed
			else
			{
				hit = 0;
			}
		}
		
		else if(door == 3)
		{
			// If wumpus is in door 3 that you fired into
			if(wumpus == player -> getDoor3Ptr())
			{
				hit = 1;
			}
			// If shot missed
			else
			{
				hit = 0;
			}
		}
	}
	// If there are no arrows left
	else
	{
		cout << "You are out of arrows." << endl;
		hit = -1;
	}
	
	return hit;
}

void Hunt::moveWumpus()
{
	int move;
	
	// Random number between 1-3
	move = rand()%3+1;
	
	// If rand num is 1, change wumpus to door1's ptr
	if(move == 1)
	{
		wumpus = wumpus->getDoor1Ptr();
	}
	// If rand num is 2, change wumpus to door2's ptr
	else if(move == 2)
	{
		wumpus = wumpus->getDoor2Ptr();
	}
	// If rand num is 3, change wumpus to door3's ptr
	else if(move == 3)
	{
		wumpus = wumpus->getDoor3Ptr();
	}
	
	// Print out new location
	cout<<"CHEATING: Wumpus in Chamber "<<wumpus->getID()<<endl;
}