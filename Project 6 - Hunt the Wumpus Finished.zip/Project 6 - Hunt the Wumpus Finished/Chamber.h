// ---------------------------------------------------------------------------
// Name: Sarah Grossheim
// Course-Section: CS255-01
// Assignment: Project 5 - Hunt the Wumpus
// Date due: 03/12/2023
// Description: Write the play(), reportPosition(), and movePlayer() functions
//				for the Hunt the Wumpus project. 
// ---------------------------------------------------------------------------
#include <iostream>
using namespace std;

class Chamber{
    private:
        int chamberID;
        Chamber* door1;
        Chamber* door2;
        Chamber* door3;

    public:
        Chamber(int id, Chamber* d1, Chamber* d2, Chamber* d3);
        void setPtrs(Chamber* d1, Chamber* d2, Chamber* d3);
        int getID();
        int getDoor1ID();
        int getDoor2ID();
        int getDoor3ID();
        Chamber* getDoor1Ptr();
        Chamber* getDoor2Ptr();
        Chamber* getDoor3Ptr();
};