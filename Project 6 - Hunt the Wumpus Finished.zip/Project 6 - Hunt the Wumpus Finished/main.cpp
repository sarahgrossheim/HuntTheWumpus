// ---------------------------------------------------------------------------
// Name: Sarah Grossheim
// Course-Section: CS255-01
// Assignment: Project 6 - Hunt the Wumpus
// Date due: 03/12/2023
// Description: Do step 3 and 4 to complete the Hunt the Wumpus game. 
// ---------------------------------------------------------------------------
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

#ifndef Incl_Hunt
#define Incl_Hunt
#include "Hunt.h"
#endif // Incl_Hunt

#ifndef Incl_Chamber
#define Incl_Chamber
#include "Chamber.h"
#endif // Incl_Chamber

int main()
{
    srand(time(0));
    Hunt gameInstance;
    gameInstance.play();
    
    return 0;
}