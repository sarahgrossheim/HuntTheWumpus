// ---------------------------------------------------------------------------
// Name: Sarah Grossheim
// Course-Section: CS255-01
// Assignment: Project 5 - Hunt the Wumpus
// Date due: 03/12/2023
// Description: Write the play(), reportPosition(), and movePlayer() functions
//				for the Hunt the Wumpus project. 
// ---------------------------------------------------------------------------
#ifndef Incl_Chamber
#define Incl_Chamber
#include "Chamber.h"
#endif // Incl_Chamber

#ifndef Incl_Hunt
#define Incl_Hunt
#include "Hunt.h"
#endif // Incl_Hunt

#include <iostream>
using namespace std;

class Hunt{
    private:
        Chamber* player;
        Chamber* bats;
        Chamber* wumpus;
        Chamber* pit;
        bool gameOver;
        int numArrows;
	
    public:
        Hunt();
        void play();
        void reportPosition();
        void movePlayer(int);
        void randomFlight();
        void killPlayer(int);
        int fire();
        void moveWumpus();
};